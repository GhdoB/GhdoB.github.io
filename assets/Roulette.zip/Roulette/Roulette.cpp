﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <limits> // Naudojama buferio valymui

using namespace std;

int spinRoulette() {
    return rand() % 37;
}

string getColor(int number) {
    if (number == 0) return "Green";
    if (number % 2 == 0) return "Black";
    return "Red";
}

bool isValidBetType(const string& betType) {
    return (betType == "number" || betType == "color" || betType == "even" || betType == "odd");
}

int main() {
    srand(time(0));
    int balance = 100;
    string betInput;
    int betAmount;

    cout << "===== Sveiki atvyke i ruletes zaidima =====\n";
    cout << "Jusu pradiniai pinigai: $" << balance << "\n";

    while (balance > 0) {
        cout << "\nTurite $" << balance << ". Kiek norite statyti? (Iveskite 0, kad iseitumete): ";
        getline(cin, betInput); // Naudojame getline vietoje cin >> betInput

        if (betInput == "CTF") { //HINT
            cout << "FLAG{C4ptureTh3Fl4g}\n";
            cout << "Paspauskite bet kuri klavisa, kad iseitumete...\n";
            cin.ignore();
            cin.get(); // Palaukti, kol vartotojas paspaus Enter
            return 0;
        }

        try {
            betAmount = stoi(betInput);
        }
        catch (invalid_argument&) {
            cout << "Klaida: Iveskite tik skaiciu\n";
            continue;
        }

        if (betAmount == 0) {
            cout << "Aciu, kad zaidete! Jusu galutinis balansas: $" << balance << "\n";
            break;
        }

        if (betAmount > balance || betAmount <= 0) {
            cout << "Negalimas statymas. Bandykite dar karta.\n";
            continue;
        }

        string betType;
        do {
            cout << "Pasirinkite statymo tipa (number, color, even, odd): ";
            cin >> betType;

            if (!isValidBetType(betType)) {
                cout << "Klaida: Netinkamas statymo tipas! Bandykite dar karta.\n";
            }
        } while (!isValidBetType(betType));

        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Išvalome buferį

        int betNumber = -1;
        string betColor;

        if (betType == "number") {
            cout << "Iveskite skaiciu (0-36): ";
            while (!(cin >> betNumber) || betNumber < 0 || betNumber > 36) {
                cout << "Klaida: Iveskite skaiciu tarp 0 ir 36: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }
        else if (betType == "color") {
            cout << "Pasirinkite spalva (Red, Black, Green): ";
            cin >> betColor;
            while (betColor != "Red" && betColor != "Black" && betColor != "Green") {
                cout << "Klaida: Iveskite 'Red', 'Black' arba 'Green': ";
                cin >> betColor;
            }
        }

        // Tik dabar sukame ruletę ir generuojame rezultatą
        int result = spinRoulette();
        string color = getColor(result);

        cout << "\nRulete sukasi...\n";
        cout << "Rezultatas: " << result << " (" << color << ")\n";

        // Patikriname laimėjimą
        if (betType == "number") {
            if (betNumber == result) {
                cout << "Sveikiname! Laimejote 35 kartus daugiau!\n";
                balance += betAmount * 35;
            }
            else {
                cout << "Deja, pralaimejote.\n";
                balance -= betAmount;
            }
        }
        else if (betType == "color") {
            if (betColor == color) {
                cout << "Sveikiname! Laimejote 2 kartus daugiau!\n";
                balance += betAmount * 2;
            }
            else {
                cout << "Deja, pralaimejote.\n";
                balance -= betAmount;
            }
        }
        else if (betType == "even") {
            if (result != 0 && result % 2 == 0) {
                cout << "Sveikiname! Skaicius yra lyginis. Laimejote!\n";
                balance += betAmount * 2;
            }
            else {
                cout << "Deja, pralaimejote.\n";
                balance -= betAmount;
            }
        }
        else if (betType == "odd") {
            if (result % 2 == 1) {
                cout << "Sveikiname! Skaicius yra nelyginis. Laimejote!\n";
                balance += betAmount * 2;
            }
            else {
                cout << "Deja, pralaimejote.\n";
                balance -= betAmount;
            }
        }
    }

    if (balance <= 0) {
        cout << "Jus neturite daugiau pinigu. Zaidimas baigtas.\n";
    }

    return 0;
}
